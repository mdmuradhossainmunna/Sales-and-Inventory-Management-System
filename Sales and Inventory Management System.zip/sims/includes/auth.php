<?php
// ==========================================================
// Session bootstrap + role-based access control helpers.
// Every protected page starts with:
//   require_once "includes/auth.php";
//   requireRole(['admin', 'inventory_manager']);
// ==========================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/../config.php";

function isLoggedIn() {
    return isset($_SESSION["user_id"]);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
}

// Pass an array of allowed roles, e.g. ['admin', 'cashier']
function requireRole($allowedRoles) {
    requireLogin();
    if (!in_array($_SESSION["role"], $allowedRoles, true)) {
        header("Location: dashboard.php?error=access_denied");
        exit;
    }
}

function currentRole() {
    return $_SESSION["role"] ?? null;
}

function currentUserId() {
    return $_SESSION["user_id"] ?? null;
}

function isAdmin() {
    return currentRole() === "admin";
}

function roleLabel($role) {
    $labels = [
        "admin" => "Administrator",
        "inventory_manager" => "Inventory Manager",
        "cashier" => "Cashier",
    ];
    return $labels[$role] ?? ucfirst($role);
}
