<?php
$role = currentRole();
$page = basename($_SERVER["PHP_SELF"]);

function navActive($file, $page) {
    return $file === $page ? "active" : "";
}
?>
<div class="sidebar">
    <div class="sidebar-brand"><img width="70" height="70" src="./images/logo.png" alt=""></div>

    <nav>
        <a href="dashboard.php" class="<?php echo navActive('dashboard.php', $page); ?>">Dashboard</a>

        <?php if ($role === "admin" || $role === "inventory_manager"): ?>
            <div class="nav-section">Inventory</div>
            <a href="products.php" class="<?php echo navActive('products.php', $page); ?>">Products</a>
            <a href="stock_in.php" class="<?php echo navActive('stock_in.php', $page); ?>">Add Stock</a>
            <a href="stock_report.php" class="<?php echo navActive('stock_report.php', $page); ?>">Stock Report</a>
        <?php endif; ?>

        <?php if ($role === "admin" || $role === "cashier"): ?>
            <div class="nav-section">Sales</div>
            <a href="new_sale.php" class="<?php echo navActive('new_sale.php', $page); ?>">New Sale</a>
            <a href="sales_report.php" class="<?php echo navActive('sales_report.php', $page); ?>">Sales Report</a>
        <?php endif; ?>

        <?php if ($role === "admin"): ?>
            <div class="nav-section">Administration</div>
            <a href="manage_users.php" class="<?php echo navActive('manage_users.php', $page); ?>">Manage Users</a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-user">
        <div class="sidebar-user-name"><?php echo htmlspecialchars($_SESSION["full_name"]); ?></div>
        <div class="sidebar-user-role"><?php echo htmlspecialchars(roleLabel($role)); ?></div>
        <a href="logout.php" class="sidebar-logout">Logout</a>
    </div>
</div>
