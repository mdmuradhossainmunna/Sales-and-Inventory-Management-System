<?php
require_once "includes/auth.php";
requireRole(["admin", "inventory_manager"]);

$errors = [];
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $product_id = (int)($_POST["product_id"] ?? 0);
    $quantity   = (int)($_POST["quantity"] ?? 0);
    $reason     = trim($_POST["reason"] ?? "Stock replenishment");

    if ($product_id <= 0) {
        $errors[] = "Please select a product.";
    }
    if ($quantity <= 0) {
        $errors[] = "Quantity must be greater than zero.";
    }

    if (empty($errors)) {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("UPDATE products SET quantity = quantity + ? WHERE id = ?");
            $stmt->bind_param("ii", $quantity, $product_id);
            $stmt->execute();
            $stmt->close();

            $uid = currentUserId();
            $stmt2 = $conn->prepare("INSERT INTO stock_movements (product_id, movement_type, quantity, reason, performed_by) VALUES (?, 'in', ?, ?, ?)");
            $stmt2->bind_param("iisi", $product_id, $quantity, $reason, $uid);
            $stmt2->execute();
            $stmt2->close();

            $conn->commit();
            $success = "Stock added successfully.";
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = "Something went wrong. Please try again.";
        }
    }
}

$products = $conn->query("SELECT id, name, sku, quantity FROM products ORDER BY name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Stock - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-shell">
    <?php include "includes/sidebar.php"; ?>

    <div class="main-content">
        <div class="page-header"><h1>Add Stock</h1></div>

        <?php foreach ($errors as $error): ?>
            <div class="msg error"><?php echo htmlspecialchars($error); ?></div>
        <?php endforeach; ?>
        <?php if ($success): ?><div class="msg success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

        <div class="card" style="max-width:560px;">
            <h3>Receive New Stock</h3>
            <form method="POST" action="stock_in.php">
                <div class="form-group">
                    <label>Product</label>
                    <select name="product_id" required>
                        <option value="">-- Select a product --</option>
                        <?php while ($p = $products->fetch_assoc()): ?>
                            <option value="<?php echo $p['id']; ?>">
                                <?php echo htmlspecialchars($p["name"]) . " (" . htmlspecialchars($p["sku"]) . ") — current: " . $p["quantity"]; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Quantity to Add</label>
                    <input type="number" name="quantity" min="1" required>
                </div>
                <div class="form-group">
                    <label>Reason / Reference (optional)</label>
                    <input type="text" name="reason" placeholder="e.g. Supplier delivery #4521">
                </div>
                <button type="submit" class="btn-block">Add Stock</button>
            </form>
        </div>

        <p><a href="products.php">&larr; Manage products instead</a> &nbsp;|&nbsp; <a href="stock_report.php">View stock report &rarr;</a></p>
    </div>
</div>
</body>
</html>
