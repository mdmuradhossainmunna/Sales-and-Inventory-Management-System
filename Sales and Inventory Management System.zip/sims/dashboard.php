<?php
require_once "includes/auth.php";
requireLogin();

$role = currentRole();

// ---- Inventory stats (admin + inventory_manager) ----
if ($role === "admin" || $role === "inventory_manager") {
    $totalProducts = $conn->query("SELECT COUNT(*) c FROM products")->fetch_assoc()["c"];
    $lowStock = $conn->query("SELECT COUNT(*) c FROM products WHERE quantity <= reorder_level")->fetch_assoc()["c"];
    $stockValue = $conn->query("SELECT SUM(quantity * cost_price) v FROM products")->fetch_assoc()["v"] ?? 0;
}

// ---- Sales stats (admin + cashier) ----
if ($role === "admin" || $role === "cashier") {
    if ($role === "admin") {
        $todaySales = $conn->query("SELECT COUNT(*) c, COALESCE(SUM(total_amount),0) t FROM sales WHERE DATE(created_at) = CURDATE()")->fetch_assoc();
        $recentSales = $conn->query("SELECT s.invoice_no, s.total_amount, s.created_at, u.full_name FROM sales s LEFT JOIN users u ON s.cashier_id = u.id ORDER BY s.created_at DESC LIMIT 5");
    } else {
        $uid = currentUserId();
        $stmt = $conn->prepare("SELECT COUNT(*) c, COALESCE(SUM(total_amount),0) t FROM sales WHERE DATE(created_at) = CURDATE() AND cashier_id = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $todaySales = $stmt->get_result()->fetch_assoc();

        $stmt2 = $conn->prepare("SELECT invoice_no, total_amount, created_at FROM sales WHERE cashier_id = ? ORDER BY created_at DESC LIMIT 5");
        $stmt2->bind_param("i", $uid);
        $stmt2->execute();
        $recentSales = $stmt2->get_result();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Dashboard - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-shell">
    <?php include "includes/sidebar.php"; ?>

    <div class="main-content">
        <div class="page-header">
            <h1>Dashboard</h1>
        </div>

        <?php if (isset($_GET["error"]) && $_GET["error"] === "access_denied"): ?>
            <div class="msg error">You don't have permission to access that page.</div>
        <?php endif; ?>

        <div class="stat-grid">
            <?php if ($role === "admin" || $role === "inventory_manager"): ?>
                <div class="stat-card">
                    <div class="stat-label">Total Products</div>
                    <div class="stat-value"><?php echo (int)$totalProducts; ?></div>
                </div>
                <div class="stat-card <?php echo $lowStock > 0 ? 'danger' : 'good'; ?>">
                    <div class="stat-label">Low Stock Items</div>
                    <div class="stat-value"><?php echo (int)$lowStock; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Stock Value (Cost)</div>
                    <div class="stat-value">&#x09F3; <?php echo number_format($stockValue, 2); ?></div>
                </div>
            <?php endif; ?>

            <?php if ($role === "admin" || $role === "cashier"): ?>
                <div class="stat-card good">
                    <div class="stat-label"><?php echo $role === 'admin' ? "Today's Sales (All)" : "My Sales Today"; ?></div>
                    <div class="stat-value"><?php echo (int)$todaySales["c"]; ?></div>
                </div>
                <div class="stat-card good">
                    <div class="stat-label">Today's Revenue</div>
                    <div class="stat-value">&#x09F3; <?php echo number_format($todaySales["t"], 2); ?></div>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($role === "admin" || $role === "inventory_manager"): ?>
        <div class="card">
            <h3>Products Needing Reorder</h3>
            <?php
            $lowStockList = $conn->query("SELECT name, sku, quantity, reorder_level FROM products WHERE quantity <= reorder_level ORDER BY quantity ASC LIMIT 8");
            if ($lowStockList->num_rows > 0):
            ?>
            <table>
                <thead><tr><th>Product</th><th>SKU</th><th>In Stock</th><th>Reorder Level</th></tr></thead>
                <tbody>
                <?php while ($row = $lowStockList->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row["name"]); ?></td>
                        <td><?php echo htmlspecialchars($row["sku"]); ?></td>
                        <td><span class="badge badge-red"><?php echo $row["quantity"]; ?></span></td>
                        <td><?php echo $row["reorder_level"]; ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
                <p class="text-muted">All products are sufficiently stocked.</p>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($role === "admin" || $role === "cashier"): ?>
        <div class="card">
            <h3>Recent Sales</h3>
            <?php if ($recentSales->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <?php if ($role === "admin"): ?><th>Cashier</th><?php endif; ?>
                        <th>Total</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $recentSales->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row["invoice_no"]); ?></td>
                        <?php if ($role === "admin"): ?><td><?php echo htmlspecialchars($row["full_name"] ?? "—"); ?></td><?php endif; ?>
                        <td>&#x09F3; <?php echo number_format($row["total_amount"], 2); ?></td>
                        <td><?php echo date("M d, Y g:i A", strtotime($row["created_at"])); ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
                <p class="text-muted">No sales recorded yet.</p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
