<?php
require_once "includes/auth.php";
requireRole(["admin"]);

$errors = [];
$success = "";
$editUser = null;

// ---- Add / Edit ----
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $full_name = trim($_POST["full_name"] ?? "");
    $username  = trim($_POST["username"] ?? "");
    $email     = trim($_POST["email"] ?? "");
    $role      = $_POST["role"] ?? "cashier";
    $status    = $_POST["status"] ?? "active";
    $password  = $_POST["password"] ?? "";
    $userId    = $_POST["user_id"] ?? null;

    $validRoles = ["admin", "inventory_manager", "cashier"];
    if (!in_array($role, $validRoles, true)) {
        $errors[] = "Invalid role selected.";
    }
    if ($full_name === "" || $username === "" || $email === "") {
        $errors[] = "Full name, username and email are required.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if (empty($errors)) {
        if ($userId) {
            // Prevent an admin from locking themselves out
            if ((int)$userId === (int)currentUserId() && $role !== "admin") {
                $errors[] = "You cannot remove your own admin role.";
            } else {
                if ($password !== "") {
                    if (strlen($password) < 6) {
                        $errors[] = "Password must be at least 6 characters.";
                    } else {
                        $hashed = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $conn->prepare("UPDATE users SET full_name=?, username=?, email=?, role=?, status=?, password=? WHERE id=?");
                        $stmt->bind_param("ssssssi", $full_name, $username, $email, $role, $status, $hashed, $userId);
                    }
                } else {
                    $stmt = $conn->prepare("UPDATE users SET full_name=?, username=?, email=?, role=?, status=? WHERE id=?");
                    $stmt->bind_param("sssssi", $full_name, $username, $email, $role, $status, $userId);
                }

                if (empty($errors)) {
                    if ($stmt->execute()) {
                        $success = "User updated successfully.";
                    } else {
                        $errors[] = "Could not update user. Username/email may already be taken.";
                    }
                    $stmt->close();
                }
            }
        } else {
            if ($password === "" || strlen($password) < 6) {
                $errors[] = "Password must be at least 6 characters.";
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, role, status) VALUES (?,?,?,?,?,?)");
                $stmt->bind_param("ssssss", $full_name, $username, $email, $hashed, $role, $status);
                if ($stmt->execute()) {
                    $success = "User created successfully.";
                } else {
                    $errors[] = "Could not create user. Username/email may already exist.";
                }
                $stmt->close();
            }
        }
    }
}

// ---- Delete ----
if (isset($_GET["delete"])) {
    $id = (int)$_GET["delete"];
    if ($id === (int)currentUserId()) {
        header("Location: manage_users.php?error=self_delete");
        exit;
    }
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_users.php?deleted=1");
    exit;
}

// ---- Load for edit ----
if (isset($_GET["edit"])) {
    $id = (int)$_GET["edit"];
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $editUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-shell">
    <?php include "includes/sidebar.php"; ?>

    <div class="main-content">
        <div class="page-header"><h1>Manage Users</h1></div>

        <?php foreach ($errors as $error): ?>
            <div class="msg error"><?php echo htmlspecialchars($error); ?></div>
        <?php endforeach; ?>
        <?php if ($success): ?><div class="msg success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
        <?php if (isset($_GET["deleted"])): ?><div class="msg success">User deleted.</div><?php endif; ?>
        <?php if (isset($_GET["error"]) && $_GET["error"] === "self_delete"): ?><div class="msg error">You cannot delete your own account.</div><?php endif; ?>

        <div class="card" style="max-width:640px;">
            <h3><?php echo $editUser ? "Edit User" : "Add New User"; ?></h3>
            <form method="POST" action="manage_users.php">
                <?php if ($editUser): ?><input type="hidden" name="user_id" value="<?php echo $editUser['id']; ?>"><?php endif; ?>
                <div class="form-row">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($editUser["full_name"] ?? ""); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" value="<?php echo htmlspecialchars($editUser["username"] ?? ""); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($editUser["email"] ?? ""); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Role</label>
                        <select name="role">
                            <?php foreach (["admin" => "Administrator", "inventory_manager" => "Inventory Manager", "cashier" => "Cashier"] as $val => $label): ?>
                                <option value="<?php echo $val; ?>" <?php echo (($editUser["role"] ?? "") === $val) ? "selected" : ""; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Password <?php echo $editUser ? '(leave blank to keep current)' : ''; ?></label>
                        <input type="password" name="password" <?php echo $editUser ? '' : 'required'; ?>>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="active" <?php echo (($editUser["status"] ?? "active") === "active") ? "selected" : ""; ?>>Active</option>
                            <option value="disabled" <?php echo (($editUser["status"] ?? "") === "disabled") ? "selected" : ""; ?>>Disabled</option>
                        </select>
                    </div>
                </div>
                <div class="row-flex mt-10">
                    <button type="submit"><?php echo $editUser ? "Save Changes" : "Create User"; ?></button>
                    <?php if ($editUser): ?><a href="manage_users.php" class="btn btn-secondary">Cancel</a><?php endif; ?>
                </div>
            </form>
        </div>

        <div class="card">
            <h3>All Users</h3>
            <table>
                <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                <?php while ($u = $users->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($u["full_name"]); ?></td>
                        <td><?php echo htmlspecialchars($u["username"]); ?></td>
                        <td><?php echo htmlspecialchars($u["email"]); ?></td>
                        <td><span class="badge badge-blue"><?php echo htmlspecialchars(roleLabel($u["role"])); ?></span></td>
                        <td>
                            <?php if ($u["status"] === "active"): ?>
                                <span class="badge badge-green">Active</span>
                            <?php else: ?>
                                <span class="badge badge-gray">Disabled</span>
                            <?php endif; ?>
                        </td>
                        <td class="row-flex">
                            <a href="manage_users.php?edit=<?php echo $u['id']; ?>" class="btn btn-sm btn-secondary">Edit</a>
                            <?php if ((int)$u["id"] !== (int)currentUserId()): ?>
                                <a href="manage_users.php?delete=<?php echo $u['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this user?');">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
