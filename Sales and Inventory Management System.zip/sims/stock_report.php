<?php
require_once "includes/auth.php";
requireRole(["admin", "inventory_manager"]);

$summary = $conn->query("SELECT COUNT(*) total, SUM(quantity <= reorder_level) low_stock, SUM(quantity * cost_price) stock_value, SUM(quantity * unit_price) retail_value FROM products")->fetch_assoc();

$products = $conn->query("SELECT * FROM products ORDER BY quantity ASC");

$movements = $conn->query("
    SELECT sm.*, p.name AS product_name, p.sku, u.full_name
    FROM stock_movements sm
    LEFT JOIN products p ON sm.product_id = p.id
    LEFT JOIN users u ON sm.performed_by = u.id
    ORDER BY sm.created_at DESC
    LIMIT 50
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Stock Report - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-shell">
    <?php include "includes/sidebar.php"; ?>

    <div class="main-content">
        <div class="page-header"><h1>Stock Report</h1></div>

        <div class="stat-grid">
            <div class="stat-card">
                <div class="stat-label">Total Products</div>
                <div class="stat-value"><?php echo (int)$summary["total"]; ?></div>
            </div>
            <div class="stat-card <?php echo $summary["low_stock"] > 0 ? 'danger' : 'good'; ?>">
                <div class="stat-label">Low Stock Items</div>
                <div class="stat-value"><?php echo (int)$summary["low_stock"]; ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Stock Value (Cost)</div>
                <div class="stat-value">&#2547; <?php echo number_format($summary["stock_value"] ?? 0, 2); ?></div>
            </div>
            <div class="stat-card good">
                <div class="stat-label">Stock Value (Retail)</div>
                <div class="stat-value">&#2547; <?php echo number_format($summary["retail_value"] ?? 0, 2); ?></div>
            </div>
        </div>

        <div class="card">
            <h3>Current Inventory Levels</h3>
            <table>
                <thead>
                    <tr><th>Product</th><th>SKU</th><th>Category</th><th>Qty</th><th>Reorder Level</th><th>Status</th></tr>
                </thead>
                <tbody>
                <?php while ($p = $products->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($p["name"]); ?></td>
                        <td><?php echo htmlspecialchars($p["sku"]); ?></td>
                        <td><?php echo htmlspecialchars($p["category"] ?: "—"); ?></td>
                        <td><?php echo $p["quantity"]; ?></td>
                        <td><?php echo $p["reorder_level"]; ?></td>
                        <td>
                            <?php if ($p["quantity"] <= $p["reorder_level"]): ?>
                                <span class="badge badge-red">Reorder Now</span>
                            <?php else: ?>
                                <span class="badge badge-green">Healthy</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <h3>Recent Stock Movements</h3>
            <table>
                <thead>
                    <tr><th>Date</th><th>Product</th><th>Type</th><th>Qty</th><th>Reason</th><th>By</th></tr>
                </thead>
                <tbody>
                <?php while ($m = $movements->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date("M d, Y g:i A", strtotime($m["created_at"])); ?></td>
                        <td><?php echo htmlspecialchars($m["product_name"] ?? "Deleted product") . " (" . htmlspecialchars($m["sku"] ?? "-") . ")"; ?></td>
                        <td>
                            <?php if ($m["movement_type"] === "in"): ?>
                                <span class="badge badge-green">Stock In</span>
                            <?php else: ?>
                                <span class="badge badge-orange">Stock Out</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $m["quantity"]; ?></td>
                        <td><?php echo htmlspecialchars($m["reason"] ?: "—"); ?></td>
                        <td><?php echo htmlspecialchars($m["full_name"] ?? "System"); ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
