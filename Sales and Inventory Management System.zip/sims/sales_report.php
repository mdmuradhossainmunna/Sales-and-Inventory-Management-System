<?php
require_once "includes/auth.php";
requireRole(["admin", "cashier"]);

$role = currentRole();
$uid = currentUserId();

$dateFrom = trim($_GET["from"] ?? date("Y-m-01"));
$dateTo   = trim($_GET["to"] ?? date("Y-m-d"));

$baseSql = "SELECT s.*, u.full_name FROM sales s LEFT JOIN users u ON s.cashier_id = u.id
            WHERE DATE(s.created_at) BETWEEN ? AND ?";

if ($role === "cashier") {
    $baseSql .= " AND s.cashier_id = ?";
    $stmt = $conn->prepare($baseSql . " ORDER BY s.created_at DESC");
    $stmt->bind_param("ssi", $dateFrom, $dateTo, $uid);
} else {
    $stmt = $conn->prepare($baseSql . " ORDER BY s.created_at DESC");
    $stmt->bind_param("ss", $dateFrom, $dateTo);
}
$stmt->execute();
$sales = $stmt->get_result();

// ---- Summary totals for the same filter ----
$sumSql = "SELECT COUNT(*) c, COALESCE(SUM(total_amount),0) t FROM sales WHERE DATE(created_at) BETWEEN ? AND ?";
if ($role === "cashier") {
    $sumSql .= " AND cashier_id = ?";
    $sstmt = $conn->prepare($sumSql);
    $sstmt->bind_param("ssi", $dateFrom, $dateTo, $uid);
} else {
    $sstmt = $conn->prepare($sumSql);
    $sstmt->bind_param("ss", $dateFrom, $dateTo);
}
$sstmt->execute();
$summary = $sstmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Sales Report - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-shell">
    <?php include "includes/sidebar.php"; ?>

    <div class="main-content">
        <div class="page-header"><h1>Sales Report</h1></div>

        <div class="card">
            <form method="GET" action="sales_report.php" class="row-flex" style="align-items:end;">
                <div class="form-group" style="margin-bottom:0;">
                    <label>From</label>
                    <input type="date" name="from" value="<?php echo htmlspecialchars($dateFrom); ?>">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label>To</label>
                    <input type="date" name="to" value="<?php echo htmlspecialchars($dateTo); ?>">
                </div>
                <button type="submit">Filter</button>
            </form>
        </div>

        <div class="stat-grid">
            <div class="stat-card">
                <div class="stat-label">Transactions</div>
                <div class="stat-value"><?php echo (int)$summary["c"]; ?></div>
            </div>
            <div class="stat-card good">
                <div class="stat-label">Total Revenue</div>
                <div class="stat-value">&#2547; <?php echo number_format($summary["t"], 2); ?></div>
            </div>
        </div>

        <div class="card">
            <h3><?php echo $role === "cashier" ? "My Sales" : "All Sales"; ?></h3>
            <table>
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <?php if ($role === "admin"): ?><th>Cashier</th><?php endif; ?>
                        <th>Total</th><th>Paid</th><th>Change</th><th>Date</th><th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($sales->num_rows === 0): ?>
                    <tr><td colspan="7" class="text-muted">No sales found for this period.</td></tr>
                <?php endif; ?>
                <?php while ($s = $sales->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($s["invoice_no"]); ?></td>
                        <?php if ($role === "admin"): ?><td><?php echo htmlspecialchars($s["full_name"] ?? "—"); ?></td><?php endif; ?>
                        <td>&#2547; <?php echo number_format($s["total_amount"], 2); ?></td>
                        <td>&#2547; <?php echo number_format($s["amount_paid"], 2); ?></td>
                        <td>&#2547; <?php echo number_format($s["change_due"], 2); ?></td>
                        <td><?php echo date("M d, Y g:i A", strtotime($s["created_at"])); ?></td>
                        <td><a href="view_sale.php?id=<?php echo $s['id']; ?>" class="btn btn-sm">View</a></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
