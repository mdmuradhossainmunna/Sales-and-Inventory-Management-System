<?php
require_once "includes/auth.php";
requireRole(["admin", "cashier"]);

if (!isset($_SESSION["cart"])) {
    $_SESSION["cart"] = [];
}

$errors = [];
$success = "";

// ---- Handle actions ----
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";

    if ($action === "add_item") {
        $product_id = (int)$_POST["product_id"];
        $quantity   = max(1, (int)$_POST["quantity"]);

        $stmt = $conn->prepare("SELECT id, name, sku, quantity, unit_price FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$product) {
            $errors[] = "Product not found.";
        } else {
            $existingQty = $_SESSION["cart"][$product_id]["quantity"] ?? 0;
            $newQty = $existingQty + $quantity;

            if ($newQty > $product["quantity"]) {
                $errors[] = "Only {$product['quantity']} unit(s) of \"{$product['name']}\" available in stock.";
            } else {
                $_SESSION["cart"][$product_id] = [
                    "product_id" => $product["id"],
                    "name" => $product["name"],
                    "sku" => $product["sku"],
                    "unit_price" => $product["unit_price"],
                    "quantity" => $newQty,
                ];
            }
        }
    }

    if ($action === "remove_item") {
        $product_id = (int)$_POST["product_id"];
        unset($_SESSION["cart"][$product_id]);
    }

    if ($action === "clear_cart") {
        $_SESSION["cart"] = [];
    }

    if ($action === "checkout") {
        $amount_paid = (float)($_POST["amount_paid"] ?? 0);
        $cart = $_SESSION["cart"];

        if (empty($cart)) {
            $errors[] = "Cart is empty.";
        } else {
            $total = 0;
            foreach ($cart as $item) {
                $total += $item["unit_price"] * $item["quantity"];
            }

            if ($amount_paid < $total) {
                $errors[] = "Amount paid must be at least the total (\$" . number_format($total, 2) . ").";
            } else {
                $conn->begin_transaction();
                try {
                    // Re-check stock right before committing (protects against races)
                    foreach ($cart as $item) {
                        $stmt = $conn->prepare("SELECT quantity FROM products WHERE id = ? FOR UPDATE");
                        $stmt->bind_param("i", $item["product_id"]);
                        $stmt->execute();
                        $available = $stmt->get_result()->fetch_assoc()["quantity"] ?? 0;
                        $stmt->close();
                        if ($item["quantity"] > $available) {
                            throw new Exception("Not enough stock for {$item['name']}.");
                        }
                    }

                    $invoiceNo = "INV" . date("Ymd") . strtoupper(substr(uniqid(), -5));
                    $change = $amount_paid - $total;
                    $cashierId = currentUserId();

                    $stmt = $conn->prepare("INSERT INTO sales (invoice_no, cashier_id, total_amount, amount_paid, change_due) VALUES (?,?,?,?,?)");
                    $stmt->bind_param("siddd", $invoiceNo, $cashierId, $total, $amount_paid, $change);
                    $stmt->execute();
                    $saleId = $stmt->insert_id;
                    $stmt->close();

                    foreach ($cart as $item) {
                        $subtotal = $item["unit_price"] * $item["quantity"];
                        $stmt = $conn->prepare("INSERT INTO sale_items (sale_id, product_id, product_name, quantity, unit_price, subtotal) VALUES (?,?,?,?,?,?)");
                        $stmt->bind_param("iisidd", $saleId, $item["product_id"], $item["name"], $item["quantity"], $item["unit_price"], $subtotal);
                        $stmt->execute();
                        $stmt->close();

                        $stmt = $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?");
                        $stmt->bind_param("ii", $item["quantity"], $item["product_id"]);
                        $stmt->execute();
                        $stmt->close();

                        $stmt = $conn->prepare("INSERT INTO stock_movements (product_id, movement_type, quantity, reason, performed_by) VALUES (?, 'out', ?, ?, ?)");
                        $reason = "Sale $invoiceNo";
                        $stmt->bind_param("iisi", $item["product_id"], $item["quantity"], $reason, $cashierId);
                        $stmt->execute();
                        $stmt->close();
                    }

                    $conn->commit();
                    $_SESSION["cart"] = [];
                    header("Location: view_sale.php?id=$saleId&new=1");
                    exit;
                } catch (Exception $e) {
                    $conn->rollback();
                    $errors[] = $e->getMessage();
                }
            }
        }
    }
}

// ---- Product list for the picker ----
$search = trim($_GET["q"] ?? "");
if ($search !== "") {
    $stmt = $conn->prepare("SELECT id, name, sku, quantity, unit_price FROM products WHERE quantity > 0 AND (name LIKE ? OR sku LIKE ?) ORDER BY name ASC LIMIT 30");
    $like = "%$search%";
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $availableProducts = $stmt->get_result();
} else {
    $availableProducts = $conn->query("SELECT id, name, sku, quantity, unit_price FROM products WHERE quantity > 0 ORDER BY name ASC LIMIT 30");
}

$cartTotal = 0;
foreach ($_SESSION["cart"] as $item) {
    $cartTotal += $item["unit_price"] * $item["quantity"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>New Sale - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-shell">
    <?php include "includes/sidebar.php"; ?>

    <div class="main-content">
        <div class="page-header"><h1>New Sale</h1></div>

        <?php foreach ($errors as $error): ?>
            <div class="msg error"><?php echo htmlspecialchars($error); ?></div>
        <?php endforeach; ?>

        <div class="pos-layout">
            <div class="card">
                <h3>Select Products</h3>
                <form method="GET" action="new_sale.php" class="row-flex mt-10" style="margin-bottom:16px;">
                    <input type="text" name="q" placeholder="Search product name or SKU" value="<?php echo htmlspecialchars($search); ?>" style="max-width:280px;">
                    <button type="submit" class="btn-sm">Search</button>
                </form>

                <table>
                    <thead><tr><th>Product</th><th>SKU</th><th>Price</th><th>Stock</th><th>Qty</th><th></th></tr></thead>
                    <tbody>
                    <?php while ($p = $availableProducts->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($p["name"]); ?></td>
                            <td><?php echo htmlspecialchars($p["sku"]); ?></td>
                            <td>$<?php echo number_format($p["unit_price"], 2); ?></td>
                            <td><?php echo $p["quantity"]; ?></td>
                            <td>
                                <form method="POST" action="new_sale.php" class="row-flex">
                                    <input type="hidden" name="action" value="add_item">
                                    <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                                    <input type="number" name="quantity" value="1" min="1" max="<?php echo $p['quantity']; ?>" class="qty-input">
                            </td>
                            <td>
                                    <button type="submit" class="btn-sm">Add</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="card">
                <h3>Cart</h3>
                <?php if (empty($_SESSION["cart"])): ?>
                    <p class="text-muted">No items yet. Add products from the left.</p>
                <?php else: ?>
                    <table class="cart-table">
                        <thead><tr><th>Item</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ($_SESSION["cart"] as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item["name"]); ?><br><span class="text-muted">$<?php echo number_format($item["unit_price"], 2); ?> each</span></td>
                                <td><?php echo $item["quantity"]; ?></td>
                                <td>$<?php echo number_format($item["unit_price"] * $item["quantity"], 2); ?></td>
                                <td>
                                    <form method="POST" action="new_sale.php">
                                        <input type="hidden" name="action" value="remove_item">
                                        <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                        <button type="submit" class="btn-sm btn-danger">✕</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                    <div class="cart-total-box">
                        <div class="total-line grand-total"><span>Total</span><span>$<?php echo number_format($cartTotal, 2); ?></span></div>
                    </div>

                    <form method="POST" action="new_sale.php" class="mt-20">
                        <input type="hidden" name="action" value="checkout">
                        <div class="form-group">
                            <label>Amount Paid ($)</label>
                            <input type="number" step="0.01" min="0" name="amount_paid" required>
                        </div>
                        <div class="row-flex">
                            <button type="submit" class="btn-block">Complete Sale</button>
                        </div>
                    </form>
                    <form method="POST" action="new_sale.php" class="mt-10">
                        <input type="hidden" name="action" value="clear_cart">
                        <button type="submit" class="btn-secondary btn-block">Clear Cart</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
