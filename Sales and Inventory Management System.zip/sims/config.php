<?php
// ============================================
// Database connection settings for XAMPP
// Default XAMPP MySQL: host=localhost, user=root, password=""
// ============================================

$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "sims_db";

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
