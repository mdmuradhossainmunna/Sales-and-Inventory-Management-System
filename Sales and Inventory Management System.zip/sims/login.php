<?php
require_once "includes/auth.php";

if (isLoggedIn()) {
    header("Location: dashboard.php");
    exit;
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "" || $password === "") {
        $errors[] = "Please enter both username and password.";
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, username, password, role, status FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if ($user["status"] === "disabled") {
                $errors[] = "This account has been disabled. Contact your administrator.";
            } elseif (password_verify($password, $user["password"])) {
                session_regenerate_id(true);
                $_SESSION["user_id"]   = $user["id"];
                $_SESSION["username"]  = $user["username"];
                $_SESSION["full_name"] = $user["full_name"];
                $_SESSION["role"]      = $user["role"];

                header("Location: dashboard.php");
                exit;
            } else {
                $errors[] = "Invalid username or password.";
            }
        } else {
            $errors[] = "Invalid username or password.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
<div class="auth-container">
    <img width="100" height="100" src="./images/logo.png" alt="">
    <h3>National Libarary and Stationary</h3>
    <p class="auth-subtitle">Sign in to continue</p>

    <?php foreach ($errors as $error): ?>
        <div class="msg error"><?php echo htmlspecialchars($error); ?></div>
    <?php endforeach; ?>

    <form method="POST" action="login.php">
        <div class="form-group">
            <label for="username">Username or Email</label>
            <input type="text" id="username" name="username" value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>" autofocus>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password">
        </div>
        <button type="submit" class="btn-block">Login</button>
    </form>
</div>
</body>
</html>
