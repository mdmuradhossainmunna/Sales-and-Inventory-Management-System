<?php
// ==========================================================
// Run this file ONCE in your browser after importing database.sql
// to create the first administrator account.
// DELETE THIS FILE (or rename it) once you have logged in,
// so nobody else can use it to create accounts.
// ==========================================================
require_once "config.php";

$errors = [];
$success = "";

// Safety: if an admin already exists, block further use of this script.
$check = $conn->query("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
$adminExists = $check && $check->num_rows > 0;

if ($_SERVER["REQUEST_METHOD"] === "POST" && !$adminExists) {
    $full_name = trim($_POST["full_name"] ?? "");
    $username  = trim($_POST["username"] ?? "");
    $email     = trim($_POST["email"] ?? "");
    $password  = $_POST["password"] ?? "";

    if ($full_name === "" || $username === "" || $email === "" || $password === "") {
        $errors[] = "All fields are required.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    if (empty($errors)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, role) VALUES (?, ?, ?, ?, 'admin')");
        $stmt->bind_param("ssss", $full_name, $username, $email, $hashed);

        if ($stmt->execute()) {
            $success = "Admin account created! You can now delete create_admin.php and log in.";
            $adminExists = true;
        } else {
            $errors[] = "Could not create account (username/email may already be taken).";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Create Admin Account</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
<div class="auth-container">
    <h2>Initial Setup</h2>
    <p class="auth-subtitle">Create the first administrator account</p>

    <?php foreach ($errors as $error): ?>
        <div class="msg error"><?php echo htmlspecialchars($error); ?></div>
    <?php endforeach; ?>

    <?php if ($success): ?>
        <div class="msg success"><?php echo htmlspecialchars($success); ?></div>
        <a href="login.php" class="btn btn-block" style="text-align:center;">Go to Login</a>
    <?php elseif ($adminExists): ?>
        <div class="msg error">An admin account already exists. This script is now disabled for security. Please delete create_admin.php.</div>
        <a href="login.php" class="btn btn-block" style="text-align:center;">Go to Login</a>
    <?php else: ?>
        <form method="POST" action="create_admin.php">
            <div class="form-group">
                <label for="full_name">Full Name</label>
                <input type="text" id="full_name" name="full_name" value="<?php echo isset($full_name) ? htmlspecialchars($full_name) : ''; ?>">
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password">
            </div>
            <button type="submit" class="btn-block">Create Admin Account</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
