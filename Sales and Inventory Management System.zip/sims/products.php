<?php
require_once "includes/auth.php";
requireRole(["admin", "inventory_manager"]);

$errors = [];
$success = "";
$editProduct = null;

// ---- Handle Add / Edit submission ----
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name          = trim($_POST["name"] ?? "");
    $sku           = trim($_POST["sku"] ?? "");
    $category      = trim($_POST["category"] ?? "");
    $cost_price    = $_POST["cost_price"] ?? "";
    $unit_price    = $_POST["unit_price"] ?? "";
    $reorder_level = $_POST["reorder_level"] ?? "5";
    $product_id    = $_POST["product_id"] ?? null;

    if ($name === "" || $sku === "" || $cost_price === "" || $unit_price === "") {
        $errors[] = "Name, SKU, cost price and selling price are required.";
    }
    if (!is_numeric($cost_price) || !is_numeric($unit_price) || $cost_price < 0 || $unit_price < 0) {
        $errors[] = "Prices must be valid non-negative numbers.";
    }

    if (empty($errors)) {
        if ($product_id) {
            // Editing existing product (quantity is NOT edited here — use Add Stock page)
            $stmt = $conn->prepare("UPDATE products SET name=?, sku=?, category=?, cost_price=?, unit_price=?, reorder_level=? WHERE id=?");
            $stmt->bind_param("sssddii", $name, $sku, $category, $cost_price, $unit_price, $reorder_level, $product_id);
            if ($stmt->execute()) {
                $success = "Product updated successfully.";
            } else {
                $errors[] = "Could not update product. SKU may already be in use.";
            }
            $stmt->close();
        } else {
            // Adding a new product
            $quantity = (int)($_POST["initial_quantity"] ?? 0);
            $stmt = $conn->prepare("INSERT INTO products (name, sku, category, quantity, cost_price, unit_price, reorder_level) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param("sssiddi", $name, $sku, $category, $quantity, $cost_price, $unit_price, $reorder_level);
            if ($stmt->execute()) {
                $newId = $stmt->insert_id;
                if ($quantity > 0) {
                    $mstmt = $conn->prepare("INSERT INTO stock_movements (product_id, movement_type, quantity, reason, performed_by) VALUES (?, 'in', ?, 'Initial stock', ?)");
                    $uid = currentUserId();
                    $mstmt->bind_param("iii", $newId, $quantity, $uid);
                    $mstmt->execute();
                    $mstmt->close();
                }
                $success = "Product added successfully.";
            } else {
                $errors[] = "Could not add product. SKU may already exist.";
            }
            $stmt->close();
        }
    }
}

// ---- Handle delete ----
if (isset($_GET["delete"])) {
    $id = (int)$_GET["delete"];
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: products.php?deleted=1");
    exit;
}

// ---- Load product to edit ----
if (isset($_GET["edit"])) {
    $id = (int)$_GET["edit"];
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $editProduct = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// ---- Search ----
$search = trim($_GET["q"] ?? "");
if ($search !== "") {
    $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? OR sku LIKE ? OR category LIKE ? ORDER BY name ASC");
    $like = "%$search%";
    $stmt->bind_param("sss", $like, $like, $like);
    $stmt->execute();
    $products = $stmt->get_result();
} else {
    $products = $conn->query("SELECT * FROM products ORDER BY name ASC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Products - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-shell">
    <?php include "includes/sidebar.php"; ?>

    <div class="main-content">
        <div class="page-header"><h1>Products</h1></div>

        <?php foreach ($errors as $error): ?>
            <div class="msg error"><?php echo htmlspecialchars($error); ?></div>
        <?php endforeach; ?>
        <?php if ($success): ?><div class="msg success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
        <?php if (isset($_GET["deleted"])): ?><div class="msg success">Product deleted.</div><?php endif; ?>

        <div class="card">
            <h3><?php echo $editProduct ? "Edit Product" : "Add New Product"; ?></h3>
            <form method="POST" action="products.php">
                <?php if ($editProduct): ?>
                    <input type="hidden" name="product_id" value="<?php echo $editProduct["id"]; ?>">
                <?php endif; ?>
                <div class="form-row">
                    <div class="form-group">
                        <label>Product Name</label>
                        <input type="text" name="name" value="<?php echo htmlspecialchars($editProduct["name"] ?? ""); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>SKU / Code</label>
                        <input type="text" name="sku" value="<?php echo htmlspecialchars($editProduct["sku"] ?? ""); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Category</label>
                        <input type="text" name="category" value="<?php echo htmlspecialchars($editProduct["category"] ?? ""); ?>">
                    </div>
                    <div class="form-group">
                        <label>Reorder Level</label>
                        <input type="number" name="reorder_level" min="0" value="<?php echo htmlspecialchars($editProduct["reorder_level"] ?? "5"); ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Cost Price ( &#x09F3; )</label>
                        <input type="number" step="0.01" min="0" name="cost_price" value="<?php echo htmlspecialchars($editProduct["cost_price"] ?? ""); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Selling Price ( &#2547; )</label>
                        <input type="number" step="0.01" min="0" name="unit_price" value="<?php echo htmlspecialchars($editProduct["unit_price"] ?? ""); ?>" required>
                    </div>
                </div>
                <?php if (!$editProduct): ?>
                <div class="form-group" style="max-width:240px;">
                    <label>Initial Quantity</label>
                    <input type="number" name="initial_quantity" min="0" value="0">
                </div>
                <?php else: ?>
                    <p class="text-muted">Quantity: <strong><?php echo $editProduct["quantity"]; ?></strong> — use "Add Stock" to change it.</p>
                <?php endif; ?>

                <div class="row-flex mt-20">
                    <button type="submit"><?php echo $editProduct ? "Save Changes" : "Add Product"; ?></button>
                    <?php if ($editProduct): ?>
                        <a href="products.php" class="btn btn-secondary">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="card">
            <div class="page-header">
                <h3 style="margin:0;">All Products</h3>
                <form method="GET" action="products.php" class="row-flex">
                    <input type="text" name="q" placeholder="Search by name, SKU or category" value="<?php echo htmlspecialchars($search); ?>" style="width:260px;">
                    <button type="submit" class="btn-sm">Search</button>
                </form>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Name</th><th>SKU</th><th>Category</th><th>Qty</th>
                        <th>Cost</th><th>Price</th><th>Status</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($p = $products->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($p["name"]); ?></td>
                        <td><?php echo htmlspecialchars($p["sku"]); ?></td>
                        <td><?php echo htmlspecialchars($p["category"] ?: "—"); ?></td>
                        <td><?php echo $p["quantity"]; ?></td>
                        <td>&#2547; <?php echo number_format($p["cost_price"], 2); ?></td>
                        <td>&#2547; <?php echo number_format($p["unit_price"], 2); ?></td>
                        <td>
                            <?php if ($p["quantity"] <= $p["reorder_level"]): ?>
                                <span class="badge badge-red">Low Stock</span>
                            <?php else: ?>
                                <span class="badge badge-green">In Stock</span>
                            <?php endif; ?>
                        </td>
                        <td class="row-flex">
                            <a href="products.php?edit=<?php echo $p['id']; ?>" class="btn btn-sm btn-secondary">Edit</a>
                            <a href="products.php?delete=<?php echo $p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product? This cannot be undone.');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
