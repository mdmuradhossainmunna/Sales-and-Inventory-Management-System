<?php
require_once "includes/auth.php";
requireRole(["admin", "cashier"]);

$id = (int)($_GET["id"] ?? 0);
$role = currentRole();

$stmt = $conn->prepare("SELECT s.*, u.full_name FROM sales s LEFT JOIN users u ON s.cashier_id = u.id WHERE s.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$sale) {
    header("Location: sales_report.php");
    exit;
}

// Cashiers may only view their own sales
if ($role === "cashier" && $sale["cashier_id"] != currentUserId()) {
    header("Location: sales_report.php?error=access_denied");
    exit;
}

$items = $conn->prepare("SELECT * FROM sale_items WHERE sale_id = ?");
$items->bind_param("i", $id);
$items->execute();
$items = $items->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Invoice <?php echo htmlspecialchars($sale["invoice_no"]); ?> - SIMS</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-shell">
    <?php include "includes/sidebar.php"; ?>

    <div class="main-content">
        <div class="page-header"><h1>Invoice <?php echo htmlspecialchars($sale["invoice_no"]); ?></h1></div>

        <?php if (isset($_GET["new"])): ?>
            <div class="msg success">Sale completed successfully!</div>
        <?php endif; ?>

        <div class="card" style="max-width:640px;">
            <p><strong>Date:</strong> <?php echo date("M d, Y g:i A", strtotime($sale["created_at"])); ?></p>
            <p><strong>Cashier:</strong> <?php echo htmlspecialchars($sale["full_name"] ?? "—"); ?></p>

            <table class="mt-20">
                <thead><tr><th>Item</th><th>Qty</th><th>Unit Price</th><th class="text-right">Subtotal</th></tr></thead>
                <tbody>
                <?php while ($it = $items->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($it["product_name"]); ?></td>
                        <td><?php echo $it["quantity"]; ?></td>
                        <td>$<?php echo number_format($it["unit_price"], 2); ?></td>
                        <td class="text-right">$<?php echo number_format($it["subtotal"], 2); ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>

            <div class="cart-total-box">
                <div class="total-line"><span>Total</span><span>$<?php echo number_format($sale["total_amount"], 2); ?></span></div>
                <div class="total-line"><span>Amount Paid</span><span>$<?php echo number_format($sale["amount_paid"], 2); ?></span></div>
                <div class="total-line grand-total"><span>Change</span><span>$<?php echo number_format($sale["change_due"], 2); ?></span></div>
            </div>

            <div class="row-flex mt-20">
                <a href="sales_report.php" class="btn btn-secondary">&larr; Back to Sales Report</a>
                <button onclick="window.print()">Print Receipt</button>
            </div>
        </div>
    </div>
</div>
</body>
</html>
